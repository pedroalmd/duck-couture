// Ajuste esta URL para o endereço do seu servidor
const apiUrl = 'http://localhost:3000/products';

function createProduct() {
  // Fazendo uma requisição POST para o servidor
  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    // Enviar um corpo vazio ou mock data, pois estamos apenas simulando
    body: JSON.stringify({})
  })
  .then(response => response.text()) // ou .json() se espera-se um JSON de volta
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function updateProduct() {
  // Fazendo uma requisição PUT para o servidor
  fetch(`${apiUrl}/1234567890123`, { // Use algum identificador mock
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({})
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function searchProduct() {
  // Fazendo uma requisição GET para o servidor
  fetch(`${apiUrl}?codigoEAN=1234567890123`) // Use algum identificador mock
  .then(response => response.json())
  .then(data => {
    document.getElementById('product-result').textContent = JSON.stringify(data, null, 2);
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function deleteProduct() {
  // Fazendo uma requisição DELETE para o servidor
  fetch(`${apiUrl}/1234567890123`, { // Use algum identificador mock
    method: 'DELETE'
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}
