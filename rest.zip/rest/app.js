const apiUrl = 'http://localhost:3000/products';

function getProductData() {
  return {
    codigoEAN: document.getElementById('codigoEAN').value,
    nome: document.getElementById('nome').value,
    preco: parseFloat(document.getElementById('preco').value),
    localidadeProducao: {
      pais: document.getElementById('pais').value,
      regiao: document.getElementById('regiao').value,
      cidade: document.getElementById('cidade').value
    }
  };
}

function createProduct() {
  const productData = getProductData();
  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(productData)
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function updateProduct() {
  const productData = getProductData();
  fetch(`${apiUrl}/${productData.codigoEAN}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(productData)
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function searchProduct() {
  const productData = getProductData();
  fetch(`${apiUrl}?codigoEAN=${productData.codigoEAN}`)
  .then(response => response.json())
  .then(data => {
    document.getElementById('product-result').textContent = JSON.stringify(data, null, 2);
  })
  .catch(error => {
    console.error('Error:', error);
  });
}

function deleteProduct() {
  const productData = getProductData();
  fetch(`${apiUrl}/${productData.codigoEAN}`, {
    method: 'DELETE'
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('product-result').textContent = data;
  })
  .catch(error => {
    console.error('Error:', error);
  });
}
