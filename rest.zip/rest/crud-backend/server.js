const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors()); // Permitir CORS para todas as origens - necessário para requisições do front-end
app.use(express.json());

app.post('/products', (req, res) => {
  if (req.body.codigoEAN == "123") {
    res.status(204).send(`Produto já existe. ${req.body.codigoEAN}`);
  } else {
  res.status(200).send(`Produto inserido. ${req.body.codigoEAN}`);
  }
});

app.put('/products/:codigoEAN', (req, res) => {
    if (req.body.codigoEAN == "123") {
        res.status(204).send(`Produto não existe. ${req.body.codigoEAN}`);
      } else {
      res.status(200).send(`Produto alterado. ${req.body.codigoEAN}`);
      }});

app.get('/products', (req, res) => {
    if (req.query.codigoEAN == "123") {
        res.status(200).json({
            codigoEAN: req.query.codigoEAN,
            nome: 'Produto Exemplo',
            preco: 19.99,
            localidadeProducao: {
              pais: 'Brasil',
              regiao: 'Sudeste',
              cidade: 'São Paulo'
            }
          });
    } else {
        res.status(204).send(`Produto não existe. ${req.body.codigoEAN}`);
    }

});

app.delete('/products/:codigoEAN', (req, res) => {
    if (req.params.codigoEAN == "123") {
        res.status(200).send(`Produto deletado. ${req.params.codigoEAN}`);
    } else {
        res.status(204).send(`Produto não existe. ${req.body.codigoEAN}`);
    }
});

app.listen(PORT, () => {
  console.log(`Mock server running on http://localhost:${PORT}`);
});
