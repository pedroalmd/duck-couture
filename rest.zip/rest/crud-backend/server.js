const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors()); // Permitir CORS para todas as origens - necessário para requisições do front-end
app.use(express.json());

app.post('/products', (req, res) => {
  res.status(200).send('Produto inserido com sucesso (mock).');
});

app.put('/products/:codigoEAN', (req, res) => {
  res.status(200).send('Produto alterado com sucesso (mock).');
});

app.get('/products', (req, res) => {
  res.status(200).json({
    codigoEAN: req.query.codigoEAN,
    nome: 'Produto Exemplo',
    preco: 19.99,
    localidadeProducao: {
      pais: 'Brasil',
      regiao: 'Sudeste',
      cidade: 'São Paulo'
    }
  });
});

app.delete('/products/:codigoEAN', (req, res) => {
  res.status(200).send('Produto excluído com sucesso (mock).');
});

app.listen(PORT, () => {
  console.log(`Mock server running on http://localhost:${PORT}`);
});
